/*
 * @(#) $Header: /cvs/jsnap/src/tests/ca/forklabs/jsnap/AllTests.java,v 1.3 2006/02/08 02:04:50 forklabs Exp $
 *
 * Copyright (C) 2006  ForkLabs Daniel L�onard
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package ca.forklabs.jsnap;

import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * Class {@code AllTests} is the master test suite for the <em>jSnap</em>
 * library.
 *
 * @author   <a href="mailto:forklabs at gmail.com?subject=ca.forklabs.jsnap.AllTests">Daniel L�onard</a>
 * @version $Revision: 1.3 $
 */
public class AllTests {

   /**
    * Builds the test suite.
    * @return   the test suite.
    */
   public static Test suite() {
      TestSuite suite = new TestSuite("Master test suite for jSnap");

      suite.addTestSuite(SnappingEngineTest.class);
      suite.addTestSuite(SnappingZoneTest.class);

      suite.addTest(ca.forklabs.jsnap.engines.AllTests.suite());
      suite.addTest(ca.forklabs.jsnap.zones.AllTests.suite());
      
      return suite;
      }

   /**
    * Runs only this test suite.
    * @param   args   ignored.
    */
   public static void main(String... args) {
      junit.swingui.TestRunner.run(AllTests.class);
      }

   }

/*
 * $Log: AllTests.java,v $
 * Revision 1.3  2006/02/08 02:04:50  forklabs
 * The CVS keyword is Revision, not Version
 *
 * Revision 1.2  2006/02/01 00:14:27  forklabs
 * Generalized the snapping engine
 *
 * Revision 1.1  2006/01/28 22:03:18  forklabs
 * Initial import.
 *
 */
