/*
 * @(#) $Header: /cvs/jsnap/src/tests/ca/forklabs/jsnap/SnappingEngineTest.java,v 1.8 2006/02/11 05:31:20 forklabs Exp $
 *
 * Copyright (C) 2006  ForkLabs Daniel L�onard
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package ca.forklabs.jsnap;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Toolkit;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.geom.Rectangle2D;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import junit.framework.TestCase;
import ca.forklabs.jsnap.SnappingEngine;

/**
 * Class {@code SnappingEngineTest} tests class {@link SnappingEngine}.
 *
 * @author   <a href="mailto:forklabs at gmail.com?subject=ca.forklabs.jsnap.SnappingEngineTest">Daniel L�onard</a>
 * @version $Revision: 1.8 $
 */
public class SnappingEngineTest extends TestCase {

//---------------------------
// Constructor
//---------------------------

   /**
    * Constructor.
    * @param   name   the name of this test.
    */
   public SnappingEngineTest(String name) {
      super(name);
      }


//---------------------------
// Test methods
//---------------------------

   /**
    * Tests that the component that is inserted is well taken care of, that is
    * that the component listener that listens for movement is added and that
    * the component is added to the internal map. It also tests that when the
    * component is removed, it is removed from the internal map and that the
    * component listener is also removed. 
    */
   public void testManageAndRelease() {
      SnappingEngine<Component> engine = new SnappingEngine<Component>();

      Component component = new Component() { private static final long serialVersionUID = 1L; };
      
      engine.manage(component);
      
      ComponentListener expected = engine.getComponentListener();
      
      ComponentListener[] actuals = component.getComponentListeners();
      assertEquals(1, actuals.length);
      assertEquals(1, engine.getAllComponents().size());
      
      assertSame(expected, actuals[0]);
      
      engine.release(component);
      
      actuals = component.getComponentListeners();
      assertEquals(0, actuals.length);
      }

   /**
    * Tests that when a component is added, it is really added to the internal
    * map. Also tests that when a component is removed, it is really removed
    * from the internal map.
    */
   public void testAddAndRemove() {
      SnappingEngine<Component> engine = new SnappingEngine<Component>();

      Component[] components = new Component[] {
         new Component() { private static final long serialVersionUID = 1L; },
         new Component() { private static final long serialVersionUID = 2L; },
         new Component() { private static final long serialVersionUID = 3L; },
         new Component() { private static final long serialVersionUID = 4L; },
         };

      for (Component component : components) {
         engine.add(component);
         }
      
      Map<Component, SnappingEngine.Status> map = engine.getAllComponents();
      assertEquals(components.length, map.size());
      
      Iterator<Component> iter = engine.getAllComponents().keySet().iterator();
      for (int i = 0; iter.hasNext() && i < map.size(); i++) {
         assertEquals(components[i], iter.next());
         }

      engine.remove(components[1]);
      assertEquals(components.length - 1, map.size());
      
      iter = engine.getAllComponents().keySet().iterator();
      for (int i = 0; iter.hasNext() && i < map.size() + 1; i++) {
         if (1 == i) { continue; }
         assertEquals(components[i], iter.next());
         }
      }

   /**
    * Tests that when a component is added, it is added as active. Also tests
    * that <code>suspend()</code> and <code>restore()</code> works as expected.
    */
   public void testSuspendAndRestore() {
      SnappingEngine<Component> engine = new SnappingEngine<Component>();

      Component[] components = new Component[] {
         new Component() { private static final long serialVersionUID = 1L; },
         new Component() { private static final long serialVersionUID = 2L; },
         new Component() { private static final long serialVersionUID = 3L; },
         new Component() { private static final long serialVersionUID = 4L; },
         };

      for (Component component : components) {
         engine.add(component);
         }
      
      Map<Component, SnappingEngine.Status> map = engine.getAllComponents();
      assertEquals(components.length, map.size());
      
      Iterator<Component> iter = engine.getAllComponents().keySet().iterator();
      for (int i = 0; iter.hasNext(); i++) {
         SnappingEngine.Status status = map.get(iter.next());
         assertSame(SnappingEngine.Status.ACTIVE, status);
         }

      engine.suspend(components[1]);
      
      iter = engine.getAllComponents().keySet().iterator();
      for (int i = 0; iter.hasNext(); i++) {
         SnappingEngine.Status status = map.get(iter.next());

         if (1 == i) {
            assertSame(SnappingEngine.Status.INACTIVE, status);
            }
         else {
            assertSame(SnappingEngine.Status.ACTIVE, status);
            }
         }

      engine.restore(components[1]);

      iter = engine.getAllComponents().keySet().iterator();
      for (int i = 0; iter.hasNext(); i++) {
         SnappingEngine.Status status = map.get(iter.next());
         assertSame(SnappingEngine.Status.ACTIVE, status);
         }
      }
   
   /**
    * Tests that the snap algorithm skips the passive component that happens to
    * be the active component and skips as well inactive components
    */
   public void testSkipSameAndPassive() {
      final List<String> tokens = new LinkedList<String>();
      
      Component[] components = new Component[] {
         new Component() {
            private static final long serialVersionUID = 1L;
            @Override public Rectangle getBounds(Rectangle rv) {
               tokens.add("first");
               return new Rectangle(100, 100, 400, 300);
               }
            },
         new Component() {
            private static final long serialVersionUID = 2L;
            @Override public Rectangle getBounds(Rectangle rv) {
               tokens.add("second");
               return new Rectangle(1100, 100, 400, 300);
               }
            },
         new Component() {
            private static final long serialVersionUID = 3L;
            @Override public Rectangle getBounds(Rectangle rv) {
               tokens.add("third");
               return new Rectangle(100, 1100, 400, 300);
               }
            },
         new Component() {
            private static final long serialVersionUID = 4L;
            @Override public Rectangle getBounds(Rectangle rv) {
               tokens.add("fourth");
               return new Rectangle(1100, 1100, 400, 300);
               }
            },
         };

      SnappingEngine<Component> engine = new SnappingEngine<Component>() {
      // since the parent of the above component is null, the screen
      // will normally be sent so a bogus parent value is used instead
         @Override
         protected Rectangle getParentRectangle(Component active_component) {
            return new Rectangle(-5000, -5000, 10000, 10000);
            }
         };
      for (Component component : components) {
         engine.add(component);
         }
      
   // the test goes as follow : no component are within the reach of any other,
   // the third element is passive and the active will be the second element,
   // that means that there will only be two tokens in the list, the first and
   // the fourth.
      
      engine.suspend(components[2]);
      
      boolean has_snapped = engine.snap(components[1]);
      
   // no snap occured, that is an effect of this test
      assertEquals(false, has_snapped);
      
      assertEquals(2, tokens.size());
      assertEquals("first", tokens.get(0));
      assertEquals("fourth", tokens.get(1));
      }

   /**
    * Tests that the code does not go into neither the check against sibling
    * component or the parent component.
    */
   public void testSnapNoSiblingsNoParent() {
   // we make an engine that returns a bogus component map which has a set
   // that will blow if its iterator() method is called; a blow will also
   // occur if the parent rectangle is asked; which is what we want
      SnappingEngine<Component> engine = new SnappingEngine<Component>() {
         @Override protected Map<Component, Status> getAllComponents() {
            Map<Component, Status> map = new HashMap<Component, Status>() {
               private static final long serialVersionUID = 1L;
               @Override public Set<Component> keySet() {
                  Set<Component> set = new HashSet<Component>() {
                     private static final long serialVersionUID = 1L;
                     @Override public Iterator<Component> iterator() {
                        fail("should not have called method iterator()");
                        return super.iterator();
                        }
                     };
                  return set;
                  }
               };
            return map;
            }

         @Override protected Rectangle getParentRectangle(Component active_component) {
            fail("should not have called method getParentRectangle(Component)");
            return super.getParentRectangle(active_component);
            }
         };
      
      engine.setSnapingAgainstParent(false);
      engine.setSnapingAgainstSiblings(false);
         
      boolean expected = false;
      boolean actual = engine.snap(new Component() { private static final long serialVersionUID = 1L; });
      
      assertEquals(expected, actual);
      }
   
   /**
    * Tests that the code does not go into neither the check against sibling
    * component but the parent component.
    */
   public void testSnapNoSiblingsButParent() {
      final List<String> tokens = new LinkedList<String>();
      
   // we make an engine that returns a bogus component map which has a set
   // that will record if its iterator() method is called; a blow will
   // occur if the parent rectangle is asked; which is what we want
      SnappingEngine<Component> engine = new SnappingEngine<Component>() {
         @Override protected Map<Component, Status> getAllComponents() {
            Map<Component, Status> map = new HashMap<Component, Status>() {
               private static final long serialVersionUID = 1L;
               @Override public Set<Component> keySet() {
                  Set<Component> set = new HashSet<Component>() {
                     private static final long serialVersionUID = 1L;
                     @Override public Iterator<Component> iterator() {
                        tokens.add("iterator()");
                        return super.iterator();
                        }
                     };
                  return set;
                  }
               };
            return map;
            }

         @Override protected Rectangle getParentRectangle(Component active_component) {
            fail("should not have called method getParentRectangle(Component)");
            return super.getParentRectangle(active_component);
            }
         };
         
      engine.setSnapingAgainstParent(false);
      engine.setSnapingAgainstSiblings(true);
            
      boolean expected = false;
      boolean actual = engine.snap(new Component() { private static final long serialVersionUID = 1L; });
         
      assertEquals(expected, actual);
      assertEquals(1, tokens.size());
      assertEquals("iterator()", tokens.get(0));
      }

   /**
    * Tests that the code does go into the check against sibling components but
    * not into parent component.
    */
   public void testSnapButSiblingsNoParent() {
      final List<String> tokens = new LinkedList<String>();
      
   // we make an engine that returns a bogus component map which has a set
   // that will blow if its iterator() method is called; a recording will
   // occur if the parent rectangle is asked; which is what we want
      SnappingEngine<Component> engine = new SnappingEngine<Component>() {
         @Override protected Map<Component, Status> getAllComponents() {
            Map<Component, Status> map = new HashMap<Component, Status>() {
               private static final long serialVersionUID = 1L;
               @Override public Set<Component> keySet() {
                  Set<Component> set = new HashSet<Component>() {
                     private static final long serialVersionUID = 1L;
                     @Override public Iterator<Component> iterator() {
                        fail("should not have called method iterator()");
                        return super.iterator();
                        }
                     };
                  return set;
                  }
               };
            return map;
            }

         @Override protected Rectangle getParentRectangle(Component active_component) {
            tokens.add("getParentRectangle()");
         // the rectangle needs to be elsewhere because the component passed
         // to snap() is at x=0 and y=0 with a dimension of w=0 and h=0
            return new Rectangle(100, 100, 100, 100);
            }
         };
         
      engine.setSnapingAgainstParent(true);
      engine.setSnapingAgainstSiblings(false);
            
      boolean expected = false;
      boolean actual = engine.snap(new Component() { private static final long serialVersionUID = 1L; });
         
      assertEquals(expected, actual);
      assertEquals(1, tokens.size());
      assertEquals("getParentRectangle()", tokens.get(0));
      }

   /**
    * Tests that the code goes into the sibling components and the parent.
    */
   public void testSnapButSiblingsButParent() {
      final List<String> tokens = new LinkedList<String>();
      
   // we make an engine that returns a bogus component map which has a set
   // that will record if its iterator() method is called; a recording will
   // also occur if the parent rectangle is asked; which is what we want
      SnappingEngine<Component> engine = new SnappingEngine<Component>() {
         @Override protected Map<Component, Status> getAllComponents() {
            Map<Component, Status> map = new HashMap<Component, Status>() {
               private static final long serialVersionUID = 1L;
               @Override public Set<Component> keySet() {
                  Set<Component> set = new HashSet<Component>() {
                     private static final long serialVersionUID = 1L;
                     @Override public Iterator<Component> iterator() {
                        tokens.add("iterator()");
                        return super.iterator();
                        }
                     };
                  return set;
                  }
               };
            return map;
            }

         @Override protected Rectangle getParentRectangle(Component active_component) {
            tokens.add("getParentRectangle()");
         // the rectangle needs to be elsewhere because the component passed
         // to snap() is at x=0 and y=0 with a dimension of w=0 and h=0
            return new Rectangle(100, 100, 100, 100);
            }
         };
            
      boolean expected = false;
      boolean actual = engine.snap(new Component() { private static final long serialVersionUID = 1L; });
            
      assertEquals(expected, actual);
      assertEquals(2, tokens.size());
      assertEquals("iterator()", tokens.get(0));
      assertEquals("getParentRectangle()", tokens.get(1));
      }

   private static class ConcreteSnappingZone extends SnappingZone {

      /**
       * Makes the method visible.
       * @param   rectangle   ignored.
       * @return   always {@code null}.
       */
      @Override
      public Shape getRegionOfInterest(Rectangle2D rectangle) {
         return null;
         }

      /**
       * Makes the method visible.
       * @param   rectangle   ignored.
       * @param   snapping_distance   ignored.
       * @return   always {@code null}.
       */
      @Override
      public Rectangle2D getSnappingZone(Rectangle2D rectangle, double snapping_distance) {
         return null;
         }

      /**
       * Makes the method visible.
       * @return   always {@code null}.
       */
      @Override
      public OverlapStrategy getOverlapStrategy() { 
         return null;
         }

      /**
       * Makes the method visible.
       * @param   active_rectangle   ignored.
       * @param   passive_rectangle   ignored.
       * @return   always <em>0.0</em>.
       */
      @Override
      public double getSnapX(Rectangle2D active_rectangle, Rectangle2D passive_rectangle) {
         return 0.0;
         }

      /**
       * Makes the method visible.
       * @param   active_rectangle   ignored.
       * @param   passive_rectangle   ignored.
       * @return   always <em>0.0</em>.
       */
      @Override
      public double getSnapY(Rectangle2D active_rectangle, Rectangle2D passive_rectangle) {
         return 0.0;
         }

      }

   /**
    * Tests that the snapping algorithm really moves the active component if
    * there is a snap.
    */
   public void testSnap() {
   // the first test will snap against a sibling, the second against the parent
      final SnappingZone[] no_snap = new SnappingZone[] {
         new ConcreteSnappingZone() {
            @Override public boolean isPassiveCandidateForSnapping(Rectangle2D active_rectangle, Rectangle2D passive_rectangle, double snapping_distance) {
               return false;
               }
            },
         };
      
      final SnappingZone[] yes_snap = new SnappingZone[] {
            new ConcreteSnappingZone() {
               @Override public boolean isPassiveCandidateForSnapping(Rectangle2D active_rectangle, Rectangle2D passive_rectangle, double snapping_distance) {
                  return true;
                  }
               @Override public double getSnapX(Rectangle2D active_rectangle, Rectangle2D passive_rectangle) {
                  return 1.0;
                  }

               @Override public double getSnapY(Rectangle2D active_rectangle, Rectangle2D passive_rectangle) {
                  return 2.0;
                  }
               },
            };

      SnappingEngine<Component> engine1 = new SnappingEngine<Component>() {
         @Override protected List<SnappingZone> getParentSnappingZones() {
            return Arrays.asList(no_snap);
            }

         @Override protected List<SnappingZone> getSiblingSnappingZones() {
            return Arrays.asList(yes_snap);
            }
         };

      SnappingEngine<Component> engine2 = new SnappingEngine<Component>() {
         @Override protected List<SnappingZone> getParentSnappingZones() {
            return Arrays.asList(yes_snap);
            }

         @Override protected List<SnappingZone> getSiblingSnappingZones() {
            return Arrays.asList(no_snap);
            }
         };

      SnappingEngine<Component> engine3 = new SnappingEngine<Component>() {
         @Override protected List<SnappingZone> getParentSnappingZones() {
            return Arrays.asList(no_snap);
            }

         @Override protected List<SnappingZone> getSiblingSnappingZones() {
            return Arrays.asList(no_snap);
            }
         };

      Component component1 = new Component() { private static final long serialVersionUID = 1L; };
      Component component2 = new Component() { private static final long serialVersionUID = 1L; };

      engine1.manage(component1); engine1.manage(component2);
      engine2.manage(component1); engine2.manage(component2);
      engine3.manage(component1); engine3.manage(component2);

      assertEquals(0, component1.getX());
      assertEquals(0, component1.getY());
      assertEquals(0, component2.getX());
      assertEquals(0, component2.getY());

      boolean has_snapped_3 = engine3.snap(component1);

      assertEquals(0, component1.getX());
      assertEquals(0, component1.getY());
      assertEquals(0, component2.getX());
      assertEquals(0, component2.getY());

      boolean has_snapped_1 = engine1.snap(component1);
      boolean has_snapped_2 = engine2.snap(component2);

      assertEquals(true, has_snapped_1);
      assertEquals(true, has_snapped_2);
      assertEquals(false, has_snapped_3);

      assertEquals(1, component1.getX());
      assertEquals(2, component1.getY());
      assertEquals(1, component2.getX());
      assertEquals(2, component2.getY());
      }

   /**
    * Tests that the parent snapping zones are really the parent snapping
    * zones.
    */
   public void testGetParentSnappingZones() {
      SnappingEngine<Component> engine = new SnappingEngine<Component>();
      
      List<SnappingZone> expected = SnappingZone.getParentSnappingZones();
      List<SnappingZone> actual = engine.getParentSnappingZones();
      
      assertSame(expected, actual);
      }

   /**
    * Tests that the sibling snapping zones are really the sibling snapping
    * zones.
    */
   public void testGetSiblingSnappingZones() {
      SnappingEngine<Component> engine = new SnappingEngine<Component>();
      
      List<SnappingZone> expected = SnappingZone.getSiblingSnappingZones();
      List<SnappingZone> actual = engine.getSiblingSnappingZones();
      
      assertSame(expected, actual);
      }

   /**
    * Tests that the listener methods delegates to the correct engine method.
    */
   public void testComponentListener() {
      final List<String> list = new LinkedList<String>();
      
      final Component component = new Component() { private static final long serialVersionUID = 1L; };
      
      SnappingEngine<Component> engine = new SnappingEngine<Component>() {
         @Override public boolean snap(Component active_component) { assertSame(component, active_component); list.add("snap"); return true; }
         };

      ComponentListener listener = engine.getComponentListener();
      
      ComponentEvent event = new ComponentEvent(component, 0);
      
      listener.componentMoved(event);
      listener.componentResized(event);
      listener.componentShown(event);
      listener.componentHidden(event);
      
      assertEquals(1, list.size());
      
      assertEquals("snap", list.get(0));
      }

   /**
    * Tests that the correct parent rectangle is used, and when the component
    * has a parent and when the component does not have a parent.
    */
   public void testGetParentRectangle() {
      Panel panel = new Panel(null);
      panel.setSize(400, 400);
      
      Label label = new Label("jUnit");
      panel.add(label);

      SnappingEngine<Component> engine = new SnappingEngine<Component>();
      
      Rectangle expected, actual;
      
   // the component has a parent
      expected = new Rectangle(0, 0, 400, 400);
      actual = engine.getParentRectangle(label);
      assertEquals(expected, actual);

   // the component does not have a parent, much like a window
      Dimension screen_size = Toolkit.getDefaultToolkit().getScreenSize();
      expected = new Rectangle(0, 0, screen_size.width, screen_size.height);
      actual = engine.getParentRectangle(panel);
      assertEquals(expected, actual);
      }


//---------------------------
// Class methods
//---------------------------

   /**
    * Runs only this test.
    * @param   args   ignored.
    */
   public static void main(String... args) {
      junit.swingui.TestRunner.run(SnappingEngineTest.class);
      }

   }

/*
 * $Log: SnappingEngineTest.java,v $
 * Revision 1.8  2006/02/11 05:31:20  forklabs
 * Added configuration to snap against sibling components and the borders of the parent component.
 *
 * Revision 1.7  2006/02/08 04:16:39  forklabs
 * More tests.
 *
 * Revision 1.6  2006/02/08 03:45:58  forklabs
 * More tests.
 *
 * Revision 1.5  2006/02/08 02:04:50  forklabs
 * The CVS keyword is Revision, not Version
 *
 * Revision 1.4  2006/02/07 23:53:48  forklabs
 * Issue #6 and Issue #7
 *
 * Revision 1.3  2006/02/02 05:11:29  forklabs
 * Issue #9
 *
 * Revision 1.2  2006/02/01 00:14:27  forklabs
 * Generalized the snapping engine
 *
 * Revision 1.1  2006/01/28 22:03:18  forklabs
 * Initial import.
 *
 */
