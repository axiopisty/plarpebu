/*
 * @(#) $Header: /cvs/jsnap/src/tests/ca/forklabs/jsnap/zones/AllTests.java,v 1.5 2006/02/08 02:04:45 forklabs Exp $
 *
 * Copyright (C) 2006  ForkLabs Daniel L�onard
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package ca.forklabs.jsnap.zones;

import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * Class {@code AllTests} is the test suite for all tests in package
 * {@link ca.forklabs.jsnap.zones}.
 *
 * @author   <a href="mailto:forklabs at gmail.com?subject=ca.forklabs.jsnap.zones.AllTests">Daniel L�onard</a>
 * @version $Revision: 1.5 $
 */
public class AllTests {

   /**
    * Builds the test suite.
    * @return   the test suite.
    */
   public static Test suite() {
      TestSuite suite = new TestSuite("Test suite for the snapping zones");

      suite.addTestSuite(NECornerSnapsToNECornerTest.class);
      suite.addTestSuite(NECornerSnapsToNWCornerTest.class);
      suite.addTestSuite(NECornerSnapsToSECornerTest.class);
      suite.addTestSuite(NECornerSnapsToSWCornerTest.class);
      suite.addTestSuite(NWCornerSnapsToNECornerTest.class);
      suite.addTestSuite(NWCornerSnapsToNWCornerTest.class);
      suite.addTestSuite(NWCornerSnapsToSECornerTest.class);
      suite.addTestSuite(NWCornerSnapsToSWCornerTest.class);
      suite.addTestSuite(SECornerSnapsToNECornerTest.class);
      suite.addTestSuite(SECornerSnapsToNWCornerTest.class);
      suite.addTestSuite(SECornerSnapsToSECornerTest.class);
      suite.addTestSuite(SECornerSnapsToSWCornerTest.class);
      suite.addTestSuite(SWCornerSnapsToNECornerTest.class);
      suite.addTestSuite(SWCornerSnapsToNWCornerTest.class);
      suite.addTestSuite(SWCornerSnapsToSECornerTest.class);
      suite.addTestSuite(SWCornerSnapsToSWCornerTest.class);
      suite.addTestSuite(EastEdgeSnapsToEastEdgeTest.class);
      suite.addTestSuite(EastEdgeSnapsToWestEdgeTest.class);
      suite.addTestSuite(NorthEdgeSnapsToNorthEdgeTest.class);
      suite.addTestSuite(NorthEdgeSnapsToSouthEdgeTest.class);
      suite.addTestSuite(SouthEdgeSnapsToNorthEdgeTest.class);
      suite.addTestSuite(SouthEdgeSnapsToSouthEdgeTest.class);
      suite.addTestSuite(WestEdgeSnapsToEastEdgeTest.class);
      suite.addTestSuite(WestEdgeSnapsToWestEdgeTest.class);

      return suite;
      }

   /**
    * Runs only this test suite.
    * @param   args   ignored.
    */
   public static void main(String... args) {
      junit.swingui.TestRunner.run(AllTests.class);
      }

   }

/*
 * $Log: AllTests.java,v $
 * Revision 1.5  2006/02/08 02:04:45  forklabs
 * The CVS keyword is Revision, not Version
 *
 * Revision 1.4  2006/02/07 23:53:02  forklabs
 * Issue #6 and Issue #7
 *
 * Revision 1.3  2006/01/30 03:19:58  forklabs
 * Issue #15, #16, #17 and #18.
 *
 * Revision 1.2  2006/01/30 02:02:30  forklabs
 * Made the name more explicit and redefined snapping zones and region of interest.
 *
 * Revision 1.1  2006/01/28 22:03:19  forklabs
 * Initial import.
 *
 */
