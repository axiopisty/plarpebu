/*
 * @(#) $Header: /cvs/jsnap/src/tests/ca/forklabs/jsnap/zones/SWCornerSnapsToNWCornerTest.java,v 1.2 2006/02/08 02:04:48 forklabs Exp $
 *
 * Copyright (C) 2006  ForkLabs Daniel L�onard
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package ca.forklabs.jsnap.zones;

import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import junit.framework.TestCase;
import ca.forklabs.jsnap.SnappingZone;
import ca.forklabs.jsnap.zones.SWCornerSnapsToNWCorner;

/**
 * Class {@code SWCornerSnapsToNWCornerTest} tests class
 * {@link SWCornerSnapsToNWCorner}.
 *
 * @author   <a href="mailto:forklabs at gmail.com?subject=ca.forklabs.jsnap.zones.SWCornerSnapsToNWCornerTest">Daniel L�onard</a>
 * @version $Revision: 1.2 $
 */
public class SWCornerSnapsToNWCornerTest extends TestCase {

//---------------------------
// Constructor
//---------------------------
   
   /**
    * Constructor.
    * @param   name   the name of this test.
    */
   public SWCornerSnapsToNWCornerTest(String name) {
      super(name);
      }
   

//---------------------------
// Test methods
//---------------------------

   /**
    * Tests that the region of interest of the rectangle is its south-west
    * corner.
    */
   public void testGetRegionOfInterest() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);
      
      SWCornerSnapsToNWCorner south_west_corner = new SWCornerSnapsToNWCorner();
      Shape region_of_interest = south_west_corner.getRegionOfInterest(rectangle);
      
      Rectangle expected = new Rectangle(42, 84, 0, 0);
      Rectangle actual = region_of_interest.getBounds();

      assertEquals(expected, actual);
      }

   /**
    * Tests that the snapping zone of the rectangle is a square centered on
    * the north west corner whose side is twice the snapping distance.
    */
   public void testGetSnappingZone() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);
      
      SWCornerSnapsToNWCorner south_west_corner = new SWCornerSnapsToNWCorner();
      Rectangle2D snapping_zone = south_west_corner.getSnappingZone(rectangle, 10.0);
      
      Rectangle expected = new Rectangle(32, 32, 20, 20);
      Rectangle actual = snapping_zone.getBounds();

      assertEquals(expected, actual);
      }

   /**
    * Tests that the overlap strategy is {@link SnappingZone#NOT_IMPORTANT}.
    */
   public void testGetOverlapStrategy() {
      SWCornerSnapsToNWCorner south_west_corner = new SWCornerSnapsToNWCorner();

      SnappingZone.OverlapStrategy expected = SnappingZone.NOT_IMPORTANT;
      SnappingZone.OverlapStrategy actual = south_west_corner.getOverlapStrategy();
      
      assertSame(expected, actual);
      }

   /**
    * Tests that the <em>x</em> coordinate to give the active rectangle is the
    * passive rectangle <em>x</em> coordinate.
    */
   public void testGetSnapX() {
      Rectangle passive = new Rectangle(42, 42, 42, 42);
      Rectangle active = new Rectangle(45, 0, 40, 40);

      double expected = 42.0;
      
      SWCornerSnapsToNWCorner south_west_corner = new SWCornerSnapsToNWCorner();
      double actual = south_west_corner.getSnapX(active, passive);
      
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the <em>y</em> coordinate to give the active rectangle is the
    * passive rectangle <em>y</em> coordinate minus the height of the active
    * rectangle.
    */
   public void testGetSnapY() {
      Rectangle passive = new Rectangle(42, 42, 42, 42);
      Rectangle active = new Rectangle(45, 0, 40, 40);

      double expected = 2.0;
      
      SWCornerSnapsToNWCorner south_west_corner = new SWCornerSnapsToNWCorner();
      double actual = south_west_corner.getSnapY(active, passive);
      
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the template method works with the parameters of class
    * {@link SWCornerSnapsToNWCorner}.
    */
   public void testIsPassiveCandidateForSnapping() {
   // there are eight positions of interest to determine if the north east
   // corner snapping zone functions properly :
   // - the corner is north of the snapping zone (bad candidate)
   // - the corner is south of the snapping zone (bad candidate)
   // - the corner is west of the snapping zone (bad candidate)
   // - the corner is east of the snapping zone (bad candidate)
   // - the corner is at the north west corner of the snapping zone
   //   (good candidate)
   // - the corner is at the north east corner of the snapping zone
   //   (good candidate)
   // - the corner is at the south east corner of the snapping zone
   //   (good candidate)
   // - the corner is at the south west corner of the snapping zone
   //   (good candidate)
      
      int[][] bounds = new int[][] {
         { 42, 0, 40, 36, },
         { 42, 0, 40, 48, },
         { 36, 0, 40, 42, },
         { 48, 0, 40, 42, },
         { 37, 0, 40, 37, },
         { 37, 0, 40, 47, },
         { 47, 0, 40, 47, },
         { 47, 0, 40, 37, },
         };
      
      Rectangle active_rectangle = new Rectangle();
      
      Rectangle passive_rectangle = new Rectangle(42, 42, 42, 42);

      String[] names = new String[] {
         "over", "below", "left", "right", "nw", "ne", "se", "sw",
         };
      
      boolean[] expected = new boolean[] {
         false, false, false, false, true, true, true, true,
         };
      
      assertEquals(expected.length, bounds.length);
      assertEquals(expected.length, names.length);
      
      SnappingZone snapping_zone = new SWCornerSnapsToNWCorner();
      double snapping_distance = 5.0;
      
      for (int i = 0; i < expected.length; i++) {
         active_rectangle.setBounds(bounds[i][0], bounds[i][1], bounds[i][2], bounds[i][3]);
         boolean actual = snapping_zone.isPassiveCandidateForSnapping(active_rectangle, passive_rectangle, snapping_distance);
         assertEquals(names[i], expected[i], actual);
         }
      }


//---------------------------
// Class methods
//---------------------------

   /**
    * Runs only this test.
    * @param   args   ignored.
    */
   public static void main(String... args) {
      junit.swingui.TestRunner.run(SWCornerSnapsToNWCornerTest.class);
      }

   }

/*
 * $Log: SWCornerSnapsToNWCornerTest.java,v $
 * Revision 1.2  2006/02/08 02:04:48  forklabs
 * The CVS keyword is Revision, not Version
 *
 * Revision 1.1  2006/01/30 03:19:21  forklabs
 * Issue #18
 *
 */
