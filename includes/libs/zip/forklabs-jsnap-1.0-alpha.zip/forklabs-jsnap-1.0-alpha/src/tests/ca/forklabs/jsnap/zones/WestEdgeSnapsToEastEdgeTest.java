/*
 * @(#) $Header: /cvs/jsnap/src/tests/ca/forklabs/jsnap/zones/WestEdgeSnapsToEastEdgeTest.java,v 1.2 2006/02/08 02:04:45 forklabs Exp $
 *
 * Copyright (C) 2006  ForkLabs Daniel L�onard
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package ca.forklabs.jsnap.zones;

import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import junit.framework.TestCase;
import ca.forklabs.jsnap.SnappingZone;
import ca.forklabs.jsnap.zones.WestEdgeSnapsToEastEdge;

/**
 * Class {@code WestEdgeSnapsToEastEdgeTest} tests class
 * {@link WestEdgeSnapsToEastEdge}.
 *
 * @author   <a href="mailto:forklabs at gmail.com?subject=ca.forklabs.jsnap.zones.WestEdgeSnapsToEastEdgeTest">Daniel L�onard</a>
 * @version $Revision: 1.2 $
 */
public class WestEdgeSnapsToEastEdgeTest extends TestCase {

//---------------------------
// Constructor
//---------------------------
   
   /**
    * Constructor.
    * @param   name   the name of this test.
    */
   public WestEdgeSnapsToEastEdgeTest(String name) {
      super(name);
      }
   

//---------------------------
// Test methods
//---------------------------

   /**
    * Tests that the region of interest of the rectangle is its west edge.
    */
   public void testGetRegionOfInterest() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);
      
      WestEdgeSnapsToEastEdge west_edge = new WestEdgeSnapsToEastEdge();
      Shape region_of_interest = west_edge.getRegionOfInterest(rectangle);
      
      Rectangle expected = new Rectangle(42, 42, 0, 42);
      Rectangle actual = region_of_interest.getBounds();

      assertEquals(expected, actual);
      }

   /**
    * Tests that the snapping zone of the rectangle is a rectangle centered on
    * the east edge that is twice as wide as the snapping distance and as high
    * as the height of the rectangle minus twice the snapping distance.
    */
   public void testGetSnappingZone() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);
      
      WestEdgeSnapsToEastEdge west_edge = new WestEdgeSnapsToEastEdge();
      Rectangle2D snapping_zone = west_edge.getSnappingZone(rectangle, 10.0);
      
      Rectangle expected = new Rectangle(74, 52, 20, 22);
      Rectangle actual = snapping_zone.getBounds();

      assertEquals(expected, actual);
      }

   /**
    * Tests that the overlap strategy is {@link SnappingZone#INFINITELY_WIDE}.
    */
   public void testGetOverlapStrategy() {
      WestEdgeSnapsToEastEdge west_edge = new WestEdgeSnapsToEastEdge();

      SnappingZone.OverlapStrategy expected = SnappingZone.INFINITELY_WIDE;
      SnappingZone.OverlapStrategy actual = west_edge.getOverlapStrategy();
      
      assertSame(expected, actual);
      }

   /**
    * Tests that the <em>x</em> coordinate to give the active rectangle is the
    * <em>x</em> coordinate of the passive rectangle plus the width of the
    * passive rectangle.
    */
   public void testGetSnapX() {
      Rectangle passive = new Rectangle(42, 42, 42, 42);
      Rectangle active = new Rectangle(90, 30, 42, 42);

      double expected = 84.0;
      
      WestEdgeSnapsToEastEdge west_edge = new WestEdgeSnapsToEastEdge();
      double actual = west_edge.getSnapX(active, passive);
      
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the <em>y</em> coordinate to give the active rectangle does not
    * change.
    */
   public void testGetSnapY() {
      Rectangle passive = new Rectangle(42, 42, 42, 42);
      Rectangle active = new Rectangle(90, 30, 42, 42);

      double expected = 30.0;
      
      WestEdgeSnapsToEastEdge west_edge = new WestEdgeSnapsToEastEdge();
      double actual = west_edge.getSnapY(active, passive);
      
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the template method works with the parameters of class
    * {@link WestEdgeSnapsToEastEdge}.
    */
   public void testIsPassiveCandidateForSnapping() {
   // there are four positions of interest to determine if the snapping zone
   // functions properly :
   // - the western border of the active rectangle is at the east of the
   //   snapping zone (bad candidate)
   // - the western border of the active rectangle is in the eastern part of the
   //   snapping zone (good candidate)
   // - the western border of the active rectangle is in the western part of the
   //   snapping zone (good candidate)
   // - the western border of the active rectangle is at the west of the
   //   snapping zone (bad candidate)
      
      int[][] bounds = new int[][] {
         { 90, 42, 50, 50, },
         { 89, 42, 50, 50, },
         { 79, 42, 50, 50, },
         { 78, 42, 50, 50, },
         };
      
      Rectangle active_rectangle = new Rectangle();
      
      Rectangle passive_rectangle = new Rectangle(42, 42, 42, 42);

      boolean[] expected = new boolean[] {
         false, true, true, false,
         };
      
      assertEquals(expected.length, bounds.length);
      
      SnappingZone snapping_zone = new WestEdgeSnapsToEastEdge();
      double snapping_distance = 5.0;
      
      for (int i = 0; i < expected.length; i++) {
         active_rectangle.setBounds(bounds[i][0], bounds[i][1], bounds[i][2], bounds[i][3]);
         boolean actual = snapping_zone.isPassiveCandidateForSnapping(active_rectangle, passive_rectangle, snapping_distance);
         assertEquals(expected[i], actual);
         }
      }


//---------------------------
// Class methods
//---------------------------

   /**
    * Runs only this test.
    * @param   args   ignored.
    */
   public static void main(String... args) {
      junit.swingui.TestRunner.run(WestEdgeSnapsToEastEdgeTest.class);
      }

   }

/*
 * $Log: WestEdgeSnapsToEastEdgeTest.java,v $
 * Revision 1.2  2006/02/08 02:04:45  forklabs
 * The CVS keyword is Revision, not Version
 *
 * Revision 1.1  2006/01/30 02:02:30  forklabs
 * Made the name more explicit and redefined snapping zones and region of interest.
 *
 */
