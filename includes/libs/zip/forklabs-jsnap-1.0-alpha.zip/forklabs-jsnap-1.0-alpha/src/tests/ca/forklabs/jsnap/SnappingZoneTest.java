/*
 * @(#) $Header: /cvs/jsnap/src/tests/ca/forklabs/jsnap/SnappingZoneTest.java,v 1.6 2006/02/08 02:04:51 forklabs Exp $
 *
 * Copyright (C) 2006  ForkLabs Daniel L�onard
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package ca.forklabs.jsnap;

import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import junit.framework.TestCase;
import ca.forklabs.jsnap.SnappingZone;

/**
 * Class {@code SnappingZoneTest} tests class {@link SnappingZone}.
 *
 * @author   <a href="mailto:forklabs at gmail.com?subject=ca.forklabs.jsnap.SnappingZoneTest">Daniel L�onard</a>
 * @version $Revision: 1.6 $
 */
public class SnappingZoneTest extends TestCase {

//---------------------------
// Constructor
//---------------------------

   /**
    * Constructor.
    * @param   name   the name of this test.
    */
   public SnappingZoneTest(String name) {
      super(name);
      }


//---------------------------
// Test methods
//---------------------------

   /**
    * Tests that there are 16 different snapping zones.
    */
   public static void testSiblingSnappingZones() {
      List<SnappingZone> list = SnappingZone.getSiblingSnappingZones();
      
      Set<SnappingZone> set = new HashSet<SnappingZone>(list);
      
      int expected = 16;
      int actual = set.size();
      assertEquals(expected, actual);
      }
   
   /**
    * Tests that there are 8 different snapping zones.
    */
   public static void testParentSnappingZones() {
      List<SnappingZone> list = SnappingZone.getParentSnappingZones();
      
      Set<SnappingZone> set = new HashSet<SnappingZone>(list);
      
      int expected = 8;
      int actual = set.size();
      assertEquals(expected, actual);
      }

   /**
    * Tests that the overlapping strategy {@link SnappingZone#INFINITELY_WIDE}
    * determines if the rectangle overlaps correctly.
    */
   public void testInfinitelyWide() {
   // five cases will be tested :
   // - the first rectangle is above the second rectangle (does not overlap)
   // - the lower part of the first rectangle overlaps the upper part of the
   //   second rectangle (overlaps)
   // - the first rectangle completely covers the second rectangle (overlaps)
   // - the upper part of the first rectangle overlaps the lower part of the
   //   second rectangle (overlaps)
   // - the first rectangle is below the second rectangle (does not overlap)
      
      int[][] bounds = new int[][] {
         { 10, 0, 10, 9, },
         { 10, 0, 10, 11, },
         { 10, 0, 10, 21, },
         { 10, 15, 10, 9, },
         { 10, 21, 10, 9, },
         };
      Rectangle first = new Rectangle();

      Rectangle second = new Rectangle(100, 10, 10, 10);
      
      boolean[] expected = new boolean[] {
         false, true, true, true, false,
         };
      
      assertEquals(expected.length, bounds.length);
      
      for (int i = 0; i < expected.length; i++) {
         first.setBounds(bounds[i][0], bounds[i][1], bounds[i][2], bounds[i][3]);
         boolean actual = SnappingZone.INFINITELY_WIDE.areOverlapping(first, second);
         assertEquals(expected[i], actual);
         }
      }
   
   /**
    * Tests that the overlapping strategy {@link SnappingZone#INFINITELY_HIGH}
    * determines if the rectangle overlaps correctly.
    */
   public void testInfinitelyHigh() {
   // five cases will be tested :
   // - the first rectangle is left of the second rectangle (does not overlap)
   // - the right part of the first rectangle overlaps the left part of the
   //   second rectangle (overlaps)
   // - the first rectangle completely covers the second rectangle (overlaps)
   // - the left part of the first rectangle overlaps the right part of the
   //   second rectangle (overlaps)
   // - the first rectangle is right of the second rectangle (does not overlap)

      int[][] bounds = new int[][] {
         { 0, 10, 9, 10, },
         { 0, 10, 11, 10, },
         { 0, 10, 21, 10, },
         { 15, 10, 9, 10, },
         { 21, 10, 9, 10, },
         };
      Rectangle first = new Rectangle();

      Rectangle second = new Rectangle(10, 100, 10, 10);
         
      boolean[] expected = new boolean[] {
         false, true, true, true, false,
         };
         
      assertEquals(expected.length, bounds.length);
         
      for (int i = 0; i < expected.length; i++) {
         first.setBounds(bounds[i][0], bounds[i][1], bounds[i][2], bounds[i][3]);
         boolean actual = SnappingZone.INFINITELY_HIGH.areOverlapping(first, second);
         assertEquals(expected[i], actual);
         }
      }

   /**
    * Tests that the overlapping strategy {@link SnappingZone#NOT_IMPORTANT}
    * determines if the rectangle overlaps correctly.
    */
   public void testNotImportant() {
   // two cases will be tested :
   // - the first rectangle covers the second rectangle
   // - the first rectangle does not cover the second rectangle at all
   // in both cases, the expected result is that the rectangle overlaps

      int[][] bounds = new int[][] {
         { 5, 5, 20, 20, },
         { 25, 25, 25, 25, },
         };
      Rectangle first = new Rectangle();

      Rectangle second = new Rectangle(10, 10, 10, 10);
            
      boolean[] expected = new boolean[] {
         true, true,
         };
            
      assertEquals(expected.length, bounds.length);
            
      for (int i = 0; i < expected.length; i++) {
         first.setBounds(bounds[i][0], bounds[i][1], bounds[i][2], bounds[i][3]);
         boolean actual = SnappingZone.NOT_IMPORTANT.areOverlapping(first, second);
         assertEquals(expected[i], actual);
         }
      }

   /**
    * Tests that the main coordinate of the west edge is the same as <em>x</em>.
    */
   public void testGetWestEdge() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);

      double expected = 42.0;
      double actual = SnappingZone.getWestEdge(rectangle);
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the main coordinate of the east edge is the same as
    * <em>x + w</em>.
    */
   public void testGetEastEdge() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);

      double expected = 84.0;
      double actual = SnappingZone.getEastEdge(rectangle);
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the main coordinate of the north edge is the same as
    * <em>y</em>.
    */
   public void testGetNorthEdge() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);

      double expected = 42.0;
      double actual = SnappingZone.getNorthEdge(rectangle);
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the main coordinate of the south edge is the same as
    * <em>y + h</em>.
    */
   public void testGetSouthEdge() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);

      double expected = 84.0;
      double actual = SnappingZone.getSouthEdge(rectangle);
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the shape of the right edge is the correct line. 
    */
   public void testGetWestEdgeShape() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);

      Rectangle expected = new Rectangle(42, 42, 0, 42);
      
      Shape edge = SnappingZone.getWestEdgeShape(rectangle);
      Rectangle actual = edge.getBounds();
      
      assertEquals(expected, actual);
      }

   /**
    * Tests that the shape of the west edge is the correct line. 
    */
   public void testGetEastEdgeShape() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);

      Rectangle expected = new Rectangle(84, 42, 0, 42);
      
      Shape edge = SnappingZone.getEastEdgeShape(rectangle);
      Rectangle actual = edge.getBounds();
      
      assertEquals(expected, actual);
      }

   /**
    * Tests that the shape of the north edge is the correct line. 
    */
   public void testGetNorthEdgeShape() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);

      Rectangle expected = new Rectangle(42, 42, 42, 0);
      Shape edge = SnappingZone.getNorthEdgeShape(rectangle);
      Rectangle actual = edge.getBounds();
      
      assertEquals(expected, actual);
      }

   /**
    * Tests that the shape of the south edge is the correct line. 
    */
   public void testGetSouthEdgeShape() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);

      Rectangle expected = new Rectangle(42, 84, 42, 0);
      Shape edge = SnappingZone.getSouthEdgeShape(rectangle);
      Rectangle actual = edge.getBounds();
      
      assertEquals(expected, actual);
      }

   /**
    * Tests the shape of the north west corner is the rectangle dot. 
    */
   public void testGetNorthWestShape() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);

      Rectangle expected = new Rectangle(42, 42, 0, 0);
      Shape edge = SnappingZone.getNorthWestCornerShape(rectangle);
      Rectangle actual = edge.getBounds();
      
      assertEquals(expected, actual);
      }

   /**
    * Tests the shape of the north east corner is the rectangle dot. 
    */
   public void testGetNorthEastShape() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);

      Rectangle expected = new Rectangle(84, 42, 0, 0);
      Shape edge = SnappingZone.getNorthEastCornerShape(rectangle);
      Rectangle actual = edge.getBounds();
      
      assertEquals(expected, actual);
      }

   /**
    * Tests the shape of the south east corner is the rectangle dot. 
    */
   public void testGetSouthEastShape() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);

      Rectangle expected = new Rectangle(84, 84, 0, 0);
      Shape edge = SnappingZone.getSouthEastCornerShape(rectangle);
      Rectangle actual = edge.getBounds();
      
      assertEquals(expected, actual);
      }

   /**
    * Tests the shape of the south west corner is the rectangle dot. 
    */
   public void testGetSouthWestShape() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);

      Rectangle expected = new Rectangle(42, 84, 0, 0);
      Shape edge = SnappingZone.getSouthWestCornerShape(rectangle);
      Rectangle actual = edge.getBounds();
      
      assertEquals(expected, actual);
      }

   /**
    * Tests that the active rectangle <em>x</em> coordinate is correct when in
    * the out-west position.
    */
   public void testGetOutWestX() {
      Rectangle passive = new Rectangle(100, 200, 300, 400);
      Rectangle active = new Rectangle(10, 20, 30, 40);
      
      double expected = 70.0;
      double actual = SnappingZone.getOutWestX(active, passive);
      assertEquals(expected, actual, 10e-6);
      }
   
   /**
    * Tests that the active rectangle <em>x</em> coordinate is correct when in
    * the in-west position.
    */
   public void testGetInWestX() {
      Rectangle passive = new Rectangle(100, 200, 300, 400);
      Rectangle active = new Rectangle(10, 20, 30, 40);
      
      double expected = 100.0;
      double actual = SnappingZone.getInWestX(active, passive);
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the active rectangle <em>x</em> coordinate is correct when in
    * the in-east position.
    */
   public void testGetInEastX() {
      Rectangle passive = new Rectangle(100, 200, 300, 400);
      Rectangle active = new Rectangle(10, 20, 30, 40);
      
      double expected = 370.0;
      double actual = SnappingZone.getInEastX(active, passive);
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the active rectangle <em>x</em> coordinate is correct when in
    * the out-east position.
    */
   public void testGetOutEastX() {
      Rectangle passive = new Rectangle(100, 200, 300, 400);
      Rectangle active = new Rectangle(10, 20, 30, 40);
      
      double expected = 400.0;
      double actual = SnappingZone.getOutEastX(active, passive);
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the active rectangle <em>y</em> coordinate is correct when in
    * the out-north position.
    */
   public void testGetOutNorthY() {
      Rectangle passive = new Rectangle(100, 200, 300, 400);
      Rectangle active = new Rectangle(10, 20, 30, 40);
      
      double expected = 160.0;
      double actual = SnappingZone.getOutNorthY(active, passive);
      assertEquals(expected, actual, 10e-6);
      }
   
   /**
    * Tests that the active rectangle <em>y</em> coordinate is correct when in
    * the in-north position.
    */
   public void testGetInNorthY() {
      Rectangle passive = new Rectangle(100, 200, 300, 400);
      Rectangle active = new Rectangle(10, 20, 30, 40);
      
      double expected = 200.0;
      double actual = SnappingZone.getInNorthY(active, passive);
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the active rectangle <em>y</em> coordinate is correct when in
    * the in-south position.
    */
   public void testGetInSouthY() {
      Rectangle passive = new Rectangle(100, 200, 300, 400);
      Rectangle active = new Rectangle(10, 20, 30, 40);
      
      double expected = 560.0;
      double actual = SnappingZone.getInSouthY(active, passive);
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the active rectangle <em>y</em> coordinate is correct when in
    * the out-south position.
    */
   public void testGetOutSouthY() {
      Rectangle passive = new Rectangle(100, 200, 300, 400);
      Rectangle active = new Rectangle(10, 20, 30, 40);
      
      double expected = 600.0;
      double actual = SnappingZone.getOutSouthY(active, passive);
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the active rectangle <em>x</em> coordinate does not change.
    */
   public void testGetSameX() {
      Rectangle passive = new Rectangle(100, 200, 300, 400);
      Rectangle active = new Rectangle(10, 20, 30, 40);
      
      double expected = 10.0;
      double actual = SnappingZone.getSameX(active, passive);
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the active rectangle <em>y</em> coordinate does not change.
    */
   public void testGetSameY() {
      Rectangle passive = new Rectangle(100, 200, 300, 400);
      Rectangle active = new Rectangle(10, 20, 30, 40);
      
      double expected = 20.0;
      double actual = SnappingZone.getSameY(active, passive);
      assertEquals(expected, actual, 10e-6);
      }

   private static class ConcreteSnappingZone extends SnappingZone {

      /**
       * Does nothing.
       * @param   rectangle   ignored.
       * @return   always {@code null}.
       */
      @Override
      protected Shape getRegionOfInterest(Rectangle2D rectangle) { return null; }

      /**
       * Does nothing.
       * @param   rectangle   ignored.
       * @param   snapping_distance   ignored.
       * @return   always {@code null}.
       */
      @Override
      protected Rectangle2D getSnappingZone(Rectangle2D rectangle, double snapping_distance) { return null; }

      /**
       * Does nothing.
       * @return   always {@code null}.
       */
      @Override
      protected OverlapStrategy getOverlapStrategy() { return null; }

      /**
       * Does nothing.
       * @param   active_rectangle   ignored.
       * @param   passive_rectangle   ignored.
       * @return   always <em>0</em>.
       */
      @Override
      protected double getSnapX(Rectangle2D active_rectangle, Rectangle2D passive_rectangle) { return 0; }

      /**
       * Does nothing.
       * @param   active_rectangle   ignored.
       * @param   passive_rectangle   ignored.
       * @return   always <em>0</em>.
       */
      @Override
      protected double getSnapY(Rectangle2D active_rectangle, Rectangle2D passive_rectangle) { return 0; }
      
      }
   
   /**
    * Tests that the template for determining a good candidate does work.
    */
   public void testIsPassiveCandidateForSnapping() {
   // there are two variables that determines if the passive rectangle is a
   // candidate for snapping :
   // - if the snapping zone of the passive rectangle contains the relevant part
   //   of active rectangle
   // and
   // - if the two rectangle would overlap given certain assumption
   //
   // there are three cases :
   // - the snapping zone does not contains the relevant part
   // - the snapping zone contains the relevant part but the two rectangles do
   //   not overlap
   // - both conditions are true
   // the first two cases will not be good candidate while the third will

      SnappingZone no_intersection = new ConcreteSnappingZone() {
         @Override protected Shape getRegionOfInterest(Rectangle2D rectangle) {
            Shape shape = new Rectangle2D.Double() {
               @Override public boolean intersects(Rectangle2D r) { return false; }
               };
            return shape;
            }
         };
   
      SnappingZone no_overlapping = new ConcreteSnappingZone() {
         @Override protected Shape getRegionOfInterest(Rectangle2D rectangle) {
            Shape shape = new Rectangle2D.Double() {
               @Override public boolean intersects(Rectangle2D r) { return true; }
               };
            return shape;
            }
         @Override protected OverlapStrategy getOverlapStrategy() {
            OverlapStrategy strategy = new OverlapStrategy() {
               @Override public boolean areOverlapping(Rectangle2D rectangle1, Rectangle2D rectangle2) { return false; }
               };
            return strategy;
            }
         };
   
      SnappingZone alway_snap = new ConcreteSnappingZone() {
         @Override protected Shape getRegionOfInterest(Rectangle2D rectangle) {
            Shape shape = new Rectangle2D.Double() {
               @Override public boolean intersects(Rectangle2D r) { return true; }
               };
            return shape;
            }
         @Override protected OverlapStrategy getOverlapStrategy() {
            OverlapStrategy strategy = SnappingZone.NOT_IMPORTANT;
            return strategy;
            }
         };

      SnappingZone[] snapping_zones = new SnappingZone[] {
         no_intersection, no_overlapping, alway_snap,
         };
   
      String[] names = new String[] {
         "no_intersection", "no_overlapping", "alway_snap",
         };
      
      boolean[] expected = new boolean[] {
         false, false, true,
         };
      
      assertEquals(expected.length, snapping_zones.length);
      assertEquals(expected.length, names.length);
      
      for (int i = 0; i < expected.length; i++) {
         boolean actual = snapping_zones[i].isPassiveCandidateForSnapping(null, null, 0);
         assertEquals(names[i], expected[i], actual);
         }
      }


//---------------------------
// Class methods
//---------------------------

   /**
    * Runs only this test.
    * @param   args   ignored.
    */
   public static void main(String... args) {
      junit.swingui.TestRunner.run(SnappingZoneTest.class);
      }

   }

/*
 * $Log: SnappingZoneTest.java,v $
 * Revision 1.6  2006/02/08 02:04:51  forklabs
 * The CVS keyword is Revision, not Version
 *
 * Revision 1.5  2006/02/08 01:54:32  forklabs
 * Issue #20
 *
 * Revision 1.4  2006/02/07 23:54:07  forklabs
 * Issue #6 and Issue #7
 *
 * Revision 1.3  2006/01/30 03:19:57  forklabs
 * Issue #15, #16, #17 and #18.
 *
 * Revision 1.2  2006/01/30 02:02:33  forklabs
 * Made the name more explicit and redefined snapping zones and region of interest.
 *
 * Revision 1.1  2006/01/28 22:03:19  forklabs
 * Initial import.
 *
 */
