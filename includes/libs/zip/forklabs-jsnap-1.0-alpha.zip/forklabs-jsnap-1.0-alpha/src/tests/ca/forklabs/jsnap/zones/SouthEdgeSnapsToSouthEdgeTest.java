/*
 * @(#) $Header: /cvs/jsnap/src/tests/ca/forklabs/jsnap/zones/SouthEdgeSnapsToSouthEdgeTest.java,v 1.2 2006/02/08 02:04:45 forklabs Exp $
 *
 * Copyright (C) 2006  ForkLabs Daniel L�onard
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package ca.forklabs.jsnap.zones;

import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import junit.framework.TestCase;
import ca.forklabs.jsnap.SnappingZone;
import ca.forklabs.jsnap.zones.SouthEdgeSnapsToSouthEdge;

/**
 * Class {@code SouthEdgeSnapsToSouthEdgeTest} tests class
 * {@link SouthEdgeSnapsToSouthEdge}.
 *
 * @author   <a href="mailto:forklabs at gmail.com?subject=ca.forklabs.jsnap.zones.SouthEdgeSnapsToSouthEdgeTest">Daniel L�onard</a>
 * @version $Revision: 1.2 $
 */
public class SouthEdgeSnapsToSouthEdgeTest extends TestCase {

//---------------------------
// Constructor
//---------------------------
   
   /**
    * Constructor.
    * @param   name   the name of this test.
    */
   public SouthEdgeSnapsToSouthEdgeTest(String name) {
      super(name);
      }
   

//---------------------------
// Test methods
//---------------------------

   /**
    * Tests that the region of interest of the rectangle is its south edge.
    */
   public void testGetRegionOfInterest() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);
      
      SouthEdgeSnapsToSouthEdge south_edge = new SouthEdgeSnapsToSouthEdge();
      Shape region_of_interest = south_edge.getRegionOfInterest(rectangle);
      
      Rectangle expected = new Rectangle(42, 84, 42, 0);
      Rectangle actual = region_of_interest.getBounds();

      assertEquals(expected, actual);
      }

   /**
    * Tests that the snapping zone of the rectangle is a rectangle centered on
    * the south edge that is twice as high as the snapping distance and as wide
    * as the width of the rectangle minus twice the snapping distance.
    */
   public void testGetSnappingZone() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);
      
      SouthEdgeSnapsToSouthEdge south_edge = new SouthEdgeSnapsToSouthEdge();
      Rectangle2D snapping_zone = south_edge.getSnappingZone(rectangle, 10);
      
      Rectangle expected = new Rectangle(52, 74, 22, 20);
      Rectangle actual = snapping_zone.getBounds();

      assertEquals(expected, actual);
      }

   /**
    * Tests that the overlap strategy is {@link SnappingZone#INFINITELY_HIGH}.
    */
   public void testGetOverlapStrategy() {
      SouthEdgeSnapsToSouthEdge south_edge = new SouthEdgeSnapsToSouthEdge();

      SnappingZone.OverlapStrategy expected = SnappingZone.INFINITELY_HIGH;
      SnappingZone.OverlapStrategy actual = south_edge.getOverlapStrategy();
      
      assertSame(expected, actual);
      }

   /**
    * Tests that the <em>x</em> coordinate to give the active rectangle is its
    * own <em>x</em> coordinate.
    */
   public void testGetSnapX() {
      Rectangle passive = new Rectangle(42, 42, 42, 42);
      Rectangle active = new Rectangle(45, 45, 40, 40);

      double expected = 45.0;
      
      SouthEdgeSnapsToSouthEdge south_edge = new SouthEdgeSnapsToSouthEdge();
      double actual = south_edge.getSnapX(active, passive);
      
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the <em>y</em> coordinate to give the active rectangle is the
    * <em>y</em> coordinate of the passive rectangle plus the height of the
    * passive rectangle minus the height of the active rectangle.
    */
   public void testGetSnapY() {
      Rectangle passive = new Rectangle(42, 42, 42, 42);
      Rectangle active = new Rectangle(45, 45, 40, 40);

      double expected = 44.0;
      
      SouthEdgeSnapsToSouthEdge south_edge = new SouthEdgeSnapsToSouthEdge();
      double actual = south_edge.getSnapY(active, passive);
      
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the template method works with the parameters of class
    * {@link SouthEdgeSnapsToSouthEdge}.
    */
   public void testIsPassiveCandidateForSnapping() {
   // there are four positions of interest to determine if the south edge
   // snapping zone functions properly :
   // - the south border of the active rectangle is north of the snapping zone
   //   (bad candidate)
   // - the south border of the active rectangle is in the northern part of the
   //   snapping zone (good candidate)
   // - the south border of the active rectangle is in the southern part of the
   //   snapping zone (good candidate)
   // - the south border of the active rectangle is south of the snapping zone
   //   (bad candidate)
      
      int[][] bounds = new int[][] {
         { 45, 45, 39, 33, },
         { 45, 45, 39, 34, },
         { 45, 45, 39, 44, },
         { 45, 45, 39, 45, },
         };
      
      Rectangle active_rectangle = new Rectangle();
      
      Rectangle passive_rectangle = new Rectangle(42, 42, 42, 42);

      String[] names = new String[] {
         "outside north", "inside north", "inside south", "outside south",   
         };
      
      boolean[] expected = new boolean[] {
         false, true, true, false,
         };
      
      assertEquals(expected.length, bounds.length);
      assertEquals(expected.length, names.length);
      
      SnappingZone snapping_zone = new SouthEdgeSnapsToSouthEdge();
      int snapping_distance = 5;
      
      for (int i = 0; i < expected.length; i++) {
         active_rectangle.setBounds(bounds[i][0], bounds[i][1], bounds[i][2], bounds[i][3]);
         boolean actual = snapping_zone.isPassiveCandidateForSnapping(active_rectangle, passive_rectangle, snapping_distance);
         assertEquals(names[i], expected[i], actual);
         }
      }


//---------------------------
// Class methods
//---------------------------

   /**
    * Runs only this test.
    * @param   args   ignored.
    */
   public static void main(String... args) {
      junit.swingui.TestRunner.run(SouthEdgeSnapsToSouthEdgeTest.class);
      }

   }

/*
 * $Log: SouthEdgeSnapsToSouthEdgeTest.java,v $
 * Revision 1.2  2006/02/08 02:04:45  forklabs
 * The CVS keyword is Revision, not Version
 *
 * Revision 1.1  2006/02/07 23:53:00  forklabs
 * Issue #6 and Issue #7
 *
 */
