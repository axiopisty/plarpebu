/*
 * @(#) $Header: /cvs/jsnap/src/tests/ca/forklabs/jsnap/engines/InternalFrameSnappingEngineTest.java,v 1.6 2006/02/08 04:16:38 forklabs Exp $
 *
 * Copyright (C) 2006  ForkLabs Daniel L�onard
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package ca.forklabs.jsnap.engines;

import java.awt.event.ComponentListener;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.swing.JInternalFrame;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import junit.framework.TestCase;
import ca.forklabs.jsnap.engines.InternalFrameSnappingEngine;

/**
 * Class {@code InternalFrameSnappingEngineTest} tests class
 * {@link InternalFrameSnappingEngine}.
 *
 * @author   <a href="mailto:forklabs at gmail.com?subject=ca.forklabs.jsnap.engines.InternalFrameSnappingEngineTest">Daniel L�onard</a>
 * @version $Revision: 1.6 $
 */
public class InternalFrameSnappingEngineTest extends TestCase {

//---------------------------
// Constructor
//---------------------------

   /**
    * Constructor.
    * @param   name   the name of this test.
    */
   public InternalFrameSnappingEngineTest(String name) {
      super(name);
      }


//---------------------------
// Test methods
//---------------------------

   private static class OpenInternalFrameSnappingEngine extends InternalFrameSnappingEngine {
      /**
       * Opens up the method.
       * @return   the component listener.
       */
      @Override public ComponentListener getComponentListener() { return super.getComponentListener(); }
      /**
       * Opens up the method.
       * @return   the map of internal frames.
       */
      @Override protected Map<JInternalFrame, Status> getAllComponents() { return super.getAllComponents(); }
      }
   
   /**
    * Tests that the internal frame that is inserted is well taken care of, that
    * is that the component listener that listens for movement is added, that
    * the internal frame listener is added and that the internal frame is added
    * to the internal map. It also tests that when the component is removed, it
    * is removed from the internal map and that both listeners are also removed. 
    */
   public void testManageAndRelease() {
      OpenInternalFrameSnappingEngine engine = new OpenInternalFrameSnappingEngine();

      JInternalFrame frame = new JInternalFrame();
      
      engine.manage(frame);
      assertEquals(1, engine.getAllComponents().size());
      
      ComponentListener component_listener = engine.getComponentListener();
      InternalFrameListener internal_frame_listener = engine.getInternalFrameListener();
      
      ComponentListener[] component_listeners = frame.getComponentListeners();
      InternalFrameListener[] internal_frame_listeners = frame.getInternalFrameListeners();

      assertEquals(1, component_listeners.length);
      assertSame(component_listener, component_listeners[0]);

   // experimentation shows that there might listeners added by the system, so
   // the test first checks that there is at least one internal frame listener
      assertTrue(1 <= internal_frame_listeners.length);
   // and that our internal frame listener is present only once
      int i = 0;
      for (InternalFrameListener ifl : internal_frame_listeners) {
         i += (internal_frame_listener == ifl) ? 1 : 0;
         }
      assertEquals(1, i);
      
      engine.release(frame);
      
      component_listeners = frame.getComponentListeners();
      internal_frame_listeners = frame.getInternalFrameListeners();
      assertEquals(0, component_listeners.length);

      assertTrue(0 <= internal_frame_listeners.length);
      i = 0;
      for (InternalFrameListener ifl : internal_frame_listeners) {
         i += (internal_frame_listener == ifl) ? 1 : 0;
         }
      assertEquals(0, i);
      }

   /**
    * Tests that the listener methods delegates to the correct engine method.
    */
   public void testInternalFrameListener() {
      final List<String> list = new LinkedList<String>();
      
      final JInternalFrame internal_frame = new JInternalFrame();
      
      InternalFrameSnappingEngine engine = new InternalFrameSnappingEngine() {
         @Override public void release(JInternalFrame frame) { assertSame(internal_frame, frame); list.add("release"); }
         @Override public void restore(JInternalFrame frame) { assertSame(internal_frame, frame); list.add("restore"); }
         @Override public void suspend(JInternalFrame frame) { assertSame(internal_frame, frame); list.add("suspend"); }
         };

      InternalFrameListener listener = engine.getInternalFrameListener();
      
      InternalFrameEvent event = new InternalFrameEvent(internal_frame, 0);
      
      listener.internalFrameOpened(event);
      listener.internalFrameClosing(event);
      listener.internalFrameClosed(event);
      listener.internalFrameIconified(event);
      listener.internalFrameDeiconified(event);
      listener.internalFrameActivated(event);
      listener.internalFrameDeactivated(event);
      
      assertEquals(4, list.size());
      
      assertEquals("restore", list.get(0));
      assertEquals("release", list.get(1));
      assertEquals("suspend", list.get(2));
      assertEquals("restore", list.get(3));
      }


//---------------------------
// Class methods
//---------------------------

   /**
    * Runs only this test.
    * @param   args   ignored.
    */
   public static void main(String... args) {
      junit.swingui.TestRunner.run(InternalFrameSnappingEngineTest.class);
      }

   }

/*
 * $Log: InternalFrameSnappingEngineTest.java,v $
 * Revision 1.6  2006/02/08 04:16:38  forklabs
 * More tests.
 *
 * Revision 1.5  2006/02/08 03:45:56  forklabs
 * More tests.
 *
 * Revision 1.4  2006/02/08 03:07:41  forklabs
 * Changed the signature to Java 5.
 *
 * Revision 1.3  2006/02/08 02:04:56  forklabs
 * The CVS keyword is Revision, not Version
 *
 * Revision 1.2  2006/02/07 23:51:54  forklabs
 * * javadoc *
 *
 * Revision 1.1  2006/02/01 00:14:28  forklabs
 * Generalized the snapping engine
 *
 */
