/*
 * @(#) $Header: /cvs/jsnap/src/tests/ca/forklabs/jsnap/zones/SECornerSnapsToNWCornerTest.java,v 1.3 2006/02/08 02:04:48 forklabs Exp $
 *
 * Copyright (C) 2006  ForkLabs Daniel L�onard
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package ca.forklabs.jsnap.zones;

import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import junit.framework.TestCase;
import ca.forklabs.jsnap.SnappingZone;
import ca.forklabs.jsnap.zones.SECornerSnapsToNWCorner;

/**
 * Class {@code SECornerSnapsToNWCornerTest} tests class
 * {@link SECornerSnapsToNWCorner}.
 *
 * @author   <a href="mailto:forklabs at gmail.com?subject=ca.forklabs.jsnap.zones.SECornerSnapsToNWCornerTest">Daniel L�onard</a>
 * @version $Revision: 1.3 $
 */
public class SECornerSnapsToNWCornerTest extends TestCase {

//---------------------------
// Constructor
//---------------------------
   
   /**
    * Constructor.
    * @param   name   the name of this test.
    */
   public SECornerSnapsToNWCornerTest(String name) {
      super(name);
      }
   

//---------------------------
// Test methods
//---------------------------

   /**
    * Tests that the region of interest of the rectangle is its south east
    * corner.
    */
   public void testGetRegionOfInterest() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);
      
      SECornerSnapsToNWCorner south_east_corner = new SECornerSnapsToNWCorner();
      Shape region_of_interest = south_east_corner.getRegionOfInterest(rectangle);
      
      Rectangle expected = new Rectangle(84, 84, 0, 0);
      Rectangle actual = region_of_interest.getBounds();

      assertEquals(expected, actual);
      }

   /**
    * Tests that the snapping zone of the rectangle is a square centered on
    * the north west corner whose side is twice the snapping distance.
    */
   public void testGetSnappingZone() {
      Rectangle rectangle = new Rectangle(42, 42, 42, 42);
      
      SECornerSnapsToNWCorner south_east_corner = new SECornerSnapsToNWCorner();
      Rectangle2D snapping_zone = south_east_corner.getSnappingZone(rectangle, 10);
      
      Rectangle expected = new Rectangle(32, 32, 20, 20);
      Rectangle actual = snapping_zone.getBounds();

      assertEquals(expected, actual);
      }

   /**
    * Tests that the overlap strategy is {@link SnappingZone#NOT_IMPORTANT}.
    */
   public void testGetOverlapStrategy() {
      SECornerSnapsToNWCorner south_east_corner = new SECornerSnapsToNWCorner();

      SnappingZone.OverlapStrategy expected = SnappingZone.NOT_IMPORTANT;
      SnappingZone.OverlapStrategy actual = south_east_corner.getOverlapStrategy();
      
      assertSame(expected, actual);
      }

   /**
    * Tests that the <em>x</em> coordinate to give the active rectangle is the
    * passive rectangle <em>x</em> coordinate minus the width of the active
    * rectangle.
    */
   public void testGetSnapX() {
      Rectangle passive = new Rectangle(42, 42, 42, 42);
      Rectangle active = new Rectangle(0, 0, 40, 40);

      double expected = 2.0;
      
      SECornerSnapsToNWCorner south_east_corner = new SECornerSnapsToNWCorner();
      double actual = south_east_corner.getSnapX(active, passive);
      
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the <em>y</em> coordinate to give the active rectangle is the
    * passive rectangle <em>y</em> coordinate minus the height of the active
    * rectangle.
    */
   public void testGetSnapY() {
      Rectangle passive = new Rectangle(42, 42, 42, 42);
      Rectangle active = new Rectangle(0, 0, 40, 40);

      double expected = 2.0;
      
      SECornerSnapsToNWCorner south_east_corner = new SECornerSnapsToNWCorner();
      double actual = south_east_corner.getSnapY(active, passive);
      
      assertEquals(expected, actual, 10e-6);
      }

   /**
    * Tests that the template method works with the parameters of class
    * {@link SECornerSnapsToNWCorner}.
    */
   public void testIsPassiveCandidateForSnapping() {
   // there are eight positions of interest to determine if the north west
   // corner snapping zone functions properly :
   // - the corner is north of the snapping zone (bad candidate)
   // - the corner is south of the snapping zone (bad candidate)
   // - the corner is west of the snapping zone (bad candidate)
   // - the corner is east of the snapping zone (bad candidate)
   // - the corner is at the north west corner of the snapping zone
   //   (good candidate)
   // - the corner is at the north east corner of the snapping zone
   //   (good candidate)
   // - the corner is at the south east corner of the snapping zone
   //   (good candidate)
   // - the corner is at the south west corner of the snapping zone
   //   (good candidate)
      
      int[][] bounds = new int[][] {
         { 2, 2, 40, 34, },
         { 2, 2, 40, 46, },
         { 2, 2, 34, 40, },
         { 2, 2, 46, 40, },
         { 2, 2, 35, 35, },
         { 2, 2, 35, 45, },
         { 2, 2, 45, 45, },
         { 2, 2, 45, 35, },
         };
      
      Rectangle active_rectangle = new Rectangle();
      
      Rectangle passive_rectangle = new Rectangle(42, 42, 42, 42);

      boolean[] expected = new boolean[] {
         false, false, false, false, true, true, true, true,
         };
      
      assertEquals(expected.length, bounds.length);
      
      SnappingZone snapping_zone = new SECornerSnapsToNWCorner();
      int snapping_distance = 5;
      
      for (int i = 0; i < expected.length; i++) {
         active_rectangle.setBounds(bounds[i][0], bounds[i][1], bounds[i][2], bounds[i][3]);
         boolean actual = snapping_zone.isPassiveCandidateForSnapping(active_rectangle, passive_rectangle, snapping_distance);
         assertEquals(expected[i], actual);
         }
      }


//---------------------------
// Class methods
//---------------------------

   /**
    * Runs only this test.
    * @param   args   ignored.
    */
   public static void main(String... args) {
      junit.swingui.TestRunner.run(SECornerSnapsToNWCornerTest.class);
      }

   }

/*
 * $Log: SECornerSnapsToNWCornerTest.java,v $
 * Revision 1.3  2006/02/08 02:04:48  forklabs
 * The CVS keyword is Revision, not Version
 *
 * Revision 1.2  2006/01/30 02:02:32  forklabs
 * Made the name more explicit and redefined snapping zones and region of interest.
 *
 */
