/*
 * @(#) $Header: /cvs/jsnap/src/spikes/ca/forklabs/jsnap/spikes/FourInternalFrames.java,v 1.4 2006/02/08 02:04:50 forklabs Exp $
 *
 * Copyright (C) 2006  ForkLabs Daniel L�onard
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package ca.forklabs.jsnap.spikes;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.WindowConstants;
import ca.forklabs.jsnap.SnappingEngine;
import ca.forklabs.jsnap.engines.InternalFrameSnappingEngine;

/**
 * Class {@code FourInternalFrames} shows the capabilities of the <em>jSnap</em>
 * library with {@link JInternalFrame}.
 *
 * @author   <a href="mailto:forklabs at gmail.com?subject=ca.forklabs.jsnap.spikes.FourInternalFrames">Daniel L�onard</a>
 * @version $Revision: 1.4 $
 */
public class FourInternalFrames {

   /**
    * Entry point of this spike.
    * @param   args   ignored.
    */
   public static void main(String... args) {
      JInternalFrame first = new JInternalFrame("jSnap :: first", false, false, false, true);
      first.setSize(200, 150);
      first.setLocation(100, 100);

      JInternalFrame second = new JInternalFrame("jSnap :: second", false, false, false, true);
      second.setSize(200, 150);
      second.setLocation(800, 100);
      
      JInternalFrame third = new JInternalFrame("jSnap :: third", false, false, false, true);
      third.setSize(200, 150);
      third.setLocation(100, 600);

      JInternalFrame fourth = new JInternalFrame("jSnap :: fourth", false, false, false, true);
      fourth.setSize(200, 150);
      fourth.setLocation(800, 600);

      SnappingEngine<JInternalFrame> engine = new InternalFrameSnappingEngine(25);
      engine.manage(first);
      engine.manage(second);
      engine.manage(third);
      engine.manage(fourth);

      JDesktopPane desktop = new JDesktopPane();
      desktop.add(first);
      desktop.add(second);
      desktop.add(third);
      desktop.add(fourth);
      
      JFrame frame = new JFrame("jSnap :: FourInternalFrames");
      frame.add(desktop);
      frame.setSize(1280, 1024);
      frame.setLocationRelativeTo(null);
      frame.setVisible(true);
      frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
      
      first.setVisible(true);
      second.setVisible(true);
      third.setVisible(true);
      fourth.setVisible(true);
      }

   }

/*
 * $Log: FourInternalFrames.java,v $
 * Revision 1.4  2006/02/08 02:04:50  forklabs
 * The CVS keyword is Revision, not Version
 *
 * Revision 1.3  2006/02/07 23:51:12  forklabs
 * * javadoc *
 *
 * Revision 1.2  2006/02/01 00:14:30  forklabs
 * Generalized the snapping engine
 *
 * Revision 1.1  2006/01/28 22:03:21  forklabs
 * Initial import.
 *
 */
