/*
 * @(#) $Header: /cvs/jsnap/src/spikes/ca/forklabs/jsnap/spikes/FridgeMagnets.java,v 1.3 2006/02/08 02:04:49 forklabs Exp $
 *
 * Copyright (C) 2006  ForkLabs Daniel L�onard
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package ca.forklabs.jsnap.spikes;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import ca.forklabs.jsnap.SnappingEngine;
import ca.forklabs.jsnap.engines.ComponentSnappingEngine;

/**
 * Class {@code FridgeMagnets} shows the capabilities of the <em>jSnap</em>
 * library with bare {@link JComponent}s.
 *
 * @author   <a href="mailto:forklabs at gmail.com?subject=ca.forklabs.jsnap.spikes.FourInternalFrames">Daniel L�onard</a>
 * @version $Revision: 1.3 $
 */
public class FridgeMagnets {

   /**
    * Entry point of this spike.
    * @param   args   ignored.
    */
   public static void main(String... args) {
      JLabel[] magnets = new JLabel[] {
         new JLabel("jSnap", JLabel.CENTER),
         new JLabel("really", JLabel.CENTER),
         new JLabel("does", JLabel.CENTER),
         new JLabel("work", JLabel.CENTER),
         };

      JPanel fridge = new JPanel();
      fridge.setLayout(null);
      
      MagnetListener listener = new MagnetListener();
      
      for (JLabel magnet : magnets) {
         fridge.add(magnet);
         
         int x = (int) (Math.random() * 600 + 100);
         int y = (int) (Math.random() * 400 + 100);
         
         magnet.setBounds(x, y, 100, 25);
         magnet.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

         magnet.addMouseMotionListener(listener);
         magnet.addMouseListener(listener);
         }

      SnappingEngine<Component> engine = new ComponentSnappingEngine(5);
      for (JLabel magnet : magnets) {
         engine.manage(magnet);
         }

      JFrame frame = new JFrame("jSnap :: Fridge Magnets");
      frame.add(fridge);
      frame.setSize(800, 600);
      frame.setLocationRelativeTo(null);
      frame.setVisible(true);
      frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
      }

   private static class MagnetListener implements MouseListener, MouseMotionListener {

      private Component magnet = null;
      private int x;
      private int y;
      
      /**
       * Sets the dragging mechanism.
       * @param   me   the mouse event.
       */
      public void mousePressed(MouseEvent me) {
         magnet = me.getComponent();
         x = me.getX();
         y = me.getY();
         }

      /**
       * Resets the dragging mechanism.
       * @param   me   the mouse event.
       */
      public void mouseReleased(MouseEvent me) {
         magnet = null;
         }

      /**
       * Moves the selected compoment.
       * @param   me   the mouse event.
       */
      public void mouseDragged(MouseEvent me) {
         int dx = me.getX() - x;
         int dy = me.getY() - y;
         magnet.setLocation(magnet.getX() + dx, magnet.getY() + dy);
         }

      /**
       * Does nothing.
       * @param   me   ignored.
       */
      public void mouseEntered(MouseEvent me) { /* nothing */ }

      /**
       * Does nothing.
       * @param   me   ignored.
       */
      public void mouseExited(MouseEvent me) { /* nothing */ }

      /**
       * Does nothing.
       * @param   me   ignored.
       */
      public void mouseMoved(MouseEvent me) { /* nothing */ }

      /**
       * Does nothing.
       * @param   me   ignored.
       */
      public void mouseClicked(MouseEvent me) { /* nothing */ }

      }
   
   }

/*
 * $Log: FridgeMagnets.java,v $
 * Revision 1.3  2006/02/08 02:04:49  forklabs
 * The CVS keyword is Revision, not Version
 *
 * Revision 1.2  2006/02/07 23:51:12  forklabs
 * * javadoc *
 *
 * Revision 1.1  2006/02/02 05:53:33  forklabs
 * A new example with JLabels.
 *
 */
