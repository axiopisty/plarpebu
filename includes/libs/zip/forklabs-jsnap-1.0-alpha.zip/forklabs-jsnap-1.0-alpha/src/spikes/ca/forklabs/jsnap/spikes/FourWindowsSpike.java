/*
 * @(#) $Header: /cvs/jsnap/src/spikes/ca/forklabs/jsnap/spikes/FourWindowsSpike.java,v 1.4 2006/02/08 02:04:50 forklabs Exp $
 *
 * Copyright (C) 2006  ForkLabs Daniel L�onard
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package ca.forklabs.jsnap.spikes;

import java.awt.Window;
import javax.swing.JFrame;
import javax.swing.WindowConstants;
import ca.forklabs.jsnap.SnappingEngine;
import ca.forklabs.jsnap.engines.WindowSnappingEngine;

/**
 * Class {@code FourWindowsSpike} shows the capabilities of the <em>jSnap</em>
 * library with {@link JFrame}.
 *
 * @author   <a href="mailto:forklabs at gmail.com?subject=ca.forklabs.jsnap.spikes.FourInternalFrames">Daniel L�onard</a>
 * @version $Revision: 1.4 $
 */
public class FourWindowsSpike {

   /**
    * Entry point of this spike.
    * @param   args   ignored.
    */
   public static void main(String... args) {
      JFrame first = new JFrame("jSnap :: first");
      first.setSize(400, 300);
      first.setLocation(100, 100);
      first.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

      JFrame second = new JFrame("jSnap :: second");
      second.setSize(400, 300);
      second.setLocation(1100, 100);
      second.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
      
      JFrame third = new JFrame("jSnap :: third");
      third.setSize(400, 300);
      third.setLocation(100, 800);
      third.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

      JFrame fourth = new JFrame("jSnap :: fourth");
      fourth.setSize(400, 300);
      fourth.setLocation(1100, 800);
      fourth.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

      SnappingEngine<Window> engine = new WindowSnappingEngine(25);
      engine.manage(first);
      engine.manage(second);
      engine.manage(third);
      engine.manage(fourth);

      first.setVisible(true);
      second.setVisible(true);
      third.setVisible(true);
      fourth.setVisible(true);
      }

   }


/*
 * $Log: FourWindowsSpike.java,v $
 * Revision 1.4  2006/02/08 02:04:50  forklabs
 * The CVS keyword is Revision, not Version
 *
 * Revision 1.3  2006/02/07 23:51:12  forklabs
 * * javadoc *
 *
 * Revision 1.2  2006/02/01 00:14:31  forklabs
 * Generalized the snapping engine
 *
 * Revision 1.1  2006/01/28 22:03:21  forklabs
 * Initial import.
 *
 */
